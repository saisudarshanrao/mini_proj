from .processor import IndicProcessor
from .evaluator import IndicEvaluator
from .collator import IndicDataCollator
